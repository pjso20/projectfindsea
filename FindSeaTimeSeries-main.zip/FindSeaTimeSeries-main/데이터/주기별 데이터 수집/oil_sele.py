#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import pandas as pd
from selenium import webdriver as wd
from selenium.webdriver import ChromeOptions
from selenium.webdriver.common.by import By


# In[ ]:


def oilCrawling():
    url = 'https://kr.investing.com/commodities/crude-oil-streaming-chart'
    path = './my_dir/chromedriver_win32/chromedriver.exe'
    options = ChromeOptions()
    driver = wd.Chrome(path,options=options)
    driver.get(url)
    driver.implicitly_wait(10)
    oil = driver.find_element(By.XPATH, '//*[@id="last_last"]').text
    return(oil)


# In[ ]:

def past_Crawling(date):
    url = 'https://kr.investing.com/commodities/crude-oil-streaming-chart'
    path = './my_dir/chromedriver_win32/chromedriver.exe'
    options = ChromeOptions()
    driver = wd.Chrome(path,options=options)
    driver.get(url)
    driver.implicitly_wait(10)
    general = driver.find_element(By.XPATH, '//*[@id="__next"]/div[2]/div/div/div[2]/main/div/div[4]/nav/div/ul/li[1]/div')
    past_data = driver.find_element(By.XPATH,'//*[@id="__next"]/div[2]/div/div/div[2]/main/div/div[4]/nav/ul/li[2]/div')
    date = driver.find_element(By.XPATH,'//*[@id="__next"]/div[2]/div/div/div[2]/main/div/div[5]/div/div/div[2]/div[2]/div[2]/div[1]/div[1]')
    start_date = driver.find_element(By.XPATH, '//*[@id="__next"]/div[2]/div/div/div[2]/main/div/div[5]/div/div/div[2]/div[2]/div[2]/div[2]/div[1]/div/div[1]/input')
    end_date = driver.find_element(By.XPATH, '//*[@id="__next"]/div[2]/div/div/div[2]/main/div/div[5]/div/div/div[2]/div[2]/div[2]/div[2]/div[1]/div/div[2]/input')
    date = pd.to_datetime(date)
    date = date.strftime('%Y-%m-%d')
    general.click()
    driver.implicitly_wait(10)
    past_data.click()
    driver.implicitly_wait(10)
    date.click()    
    start_date.send_keys('value',str(date))
    start_date.submit()
    end_date.send_keys('value',str(date))
    end_date.submit()

    set_date_btn = driver.find_element(By.XPATH, '//*[@id="__next"]/div[2]/div/div/div[2]/main/div/div[5]/div/div/div[2]/div[2]/div[2]/div[2]/div[2]/button')
    set_date_btn.click()
    driver.implicitly_wait(10)

    oil_data = driver.find_element(By.XPATH, '//*[@id="__next"]/div[2]/div/div/div[2]/main/div/div[5]/div/div/div[3]/div/table/tbody/tr/td[2]').text
    return oil_data


