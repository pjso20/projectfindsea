import oil_sele
import catch_api
import pandas as pd
from selenium import webdriver as wd
from selenium.webdriver import ChromeOptions
from selenium.webdriver.common.by import By
import requests
import datetime
from bs4 import BeautifulSoup
import math

date = datetime.date.today().isoformat()
print(date)

oil = oil_sele.oilCrawling()
print(oil)

catch = catch_api.api_day(date,'고등어')
catch.reset_index()
catch = catch.rename(columns={'위판일자':'일시'})
print(type(catch))

oil_df = pd.DataFrame([[date,oil]],columns=['일시','WTI'])
print(oil_df)

rawData = catch.merge(oil_df,on='일시',how='outer')
rawData = rawData.index('일시')
print(rawData)